﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GameCommon
{
    /// <summary>
    /// 自定义封装日志
    /// </summary>
    public class Debuger
    {
        // 是否显示日志
        static public bool EnableLog = false;

        static public void Log(object message)
        {
            Log(message, null);
        }

        static public void Log(object message, Object context)
        {
            if (EnableLog)
            {
                Debug.Log("------GAME(Time:" + Time.time + ")------" + message, context);
            }
        }

        static public void LogError(object message)
        {
            LogError(message, null);
        }

        static public void LogError(object message, Object context)
        {
            if (EnableLog)
            {
                Debug.LogError("------GAME(Time:" + Time.time + ")------" + message, context);
            }
        }

        static public void LogWarning(object message)
        {
            LogWarning(message, null);
        }

        static public void LogWarning(object message, Object context)
        {
            if (EnableLog)
            {
                Debug.LogWarning("------GAME(Time:" + Time.time + ")------" + message, context);
            }
        }
    }
}